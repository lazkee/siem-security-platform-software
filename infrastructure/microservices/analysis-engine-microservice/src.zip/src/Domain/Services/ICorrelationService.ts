export interface ICorrelationService{
    findCorrelations(): Promise<void>;
}