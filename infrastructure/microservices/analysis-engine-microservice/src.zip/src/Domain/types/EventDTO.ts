export interface EventDTO {
    type: "INFO"|"WARNING"|"ERROR";
    description: string;
}